//
//  ViewController.swift
//  celoTest
//
//  Created by Nachiket Kulkarni on 19/06/20.
//  Copyright © 2020 Nachiket. All rights reserved.
//

import UIKit
import SDWebImage
import SQLite
import Network

@available(iOS 12.0, *)
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var detailTableView: UITableView!
    var result : Response?
    var resultArray : [Result]?
    var url : String!
    var page = 1
    var selectedId : Result?
    let monitor = NWPathMonitor()
    let queue = DispatchQueue(label: "InternetConnectionMonitor")
    var net = true
    var searchedUser : [Result]?
    var searching = false
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        monitor.pathUpdateHandler = { pathUpdateHandler in
                if pathUpdateHandler.status == .satisfied {
                    print("Internet connection is on.")
                    self.url = "https://randomuser.me/api/?page=\(self.page)&results=20&seed=abc"
                    self.getData(self.url!)
                } else {
                    print("There's no internet connection.")
                    self.getDataFrmDB()
                    self.net = false
                }
            }

        monitor.start(queue: queue)
        detailTableView.dataSource = self
        detailTableView.delegate = self
        searchBar.delegate = self
        searchBar.returnKeyType = .done
        
    }


    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        debugPrint(result?.results.count)
        if searching {
            return (searchedUser!.count)
        } else {
            return (resultArray?.count ?? 0)
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = detailTableView.dequeueReusableCell(withIdentifier: "cell") as! detailTableViewCell
        
        let data = getJsonData(indexPath.row)
//        cell.lblName.text = "\(data.name)"
        
//        debugPrint(data["DOB"])
        cell.lblName.text = "Name: \(data["name"]!)"
        cell.lblDOB.text = "DOB: \(data["DOB"]!)"
        cell.lblGender.text = "Gender: \(data["gender"]!)"
        cell.imgView.sd_setImage(with: URL(string: data["img"]!), completed: nil)

        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //print((resultArray.count)!)
        
        if indexPath.row == ((resultArray?.count)! - 1) && net {
            page = page + 1
            url = "https://randomuser.me/api/?page=\(page)&results=10&seed=abc"
            getData(url!)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var selectedArray: [Result]
        if searching {
            selectedArray = searchedUser!
        } else {
            selectedArray = resultArray!
        }
        selectedId = selectedArray[indexPath.row]
        performSegue(withIdentifier: "detailViewSegue", sender: nil)
        
         
    }
    
    
    // MARK:- Get data from web
    func getData(_ url: String) {
        URLSession.shared.dataTask(with: URL(string: url)!, completionHandler: {data, response, error in
            guard let data = data, error == nil else {
                print("Error")
                return
            }
            
            do{
                let gotData = try JSONDecoder().decode(Response.self, from: data)
                if (self.resultArray != nil) {
                    self.resultArray?.append(contentsOf: gotData.results)
                }
                else
                {
                    self.resultArray = gotData.results
                }
                
                let isSave = stringFunctions.walkThroughArray(self.resultArray!)
                if !isSave{
                    self.getData(self.url)
                }
                
            }
            catch{
                print("Error while decoding  \(error)")
            }
            
            DispatchQueue.main.async
            {
            self.detailTableView.reloadData()
            }
            
            }).resume()
    }
    
    // MARK:- GET DATA FROM LOCAL DB
    func getDataFrmDB() {
        resultArray = DatabaseManager.getInstance().getTableData()
        DispatchQueue.main.async
        {
        self.detailTableView.reloadData()
        }
        
    }
    
    func getJsonData(_ index : Int) -> Dictionary <String, String> {

        let data : Result
        if searching {
            data = searchedUser![index]
        } else {
            
            data = resultArray![index]
        }
        
        let name = "\(data.name.title) \(data.name.first) \(data.name.last)"
        //let id = data.id.name
        let thumbnail = data.picture.medium
        let gender = data.gender
        let dob = converDate(data.dob.date)
        let age = "\(data.dob.age)"
        
        return["name":name,"img": thumbnail, "gender": gender, "DOB": dob, "Age": age]
        
        
    }
    
    func converDate(_ date : String) -> String {
        let formatter = DateFormatter()
        // initial date format
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z"

        // convert your string to date
        let yourDate = formatter.date(from: date)
        //then again set the date format whhich type of output you need
        formatter.dateFormat = "dd-MMM-yyyy"
        // again convert your date to string
        let myStringafd = formatter.string(from: yourDate!)
        
        return myStringafd
    }
    
    // MARK:- Prepare segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if (segue.identifier == "detailViewSegue") {
                    // initialize new view controller and cast it as your view controller
                    let details = segue.destination as! detailViewController
                    // your new view controller should have property that will store passed value
                    details.details = self.selectedId
                }
    }
    
}

    //MARK:- SEARCHBAR

@available(iOS 12.0, *)
extension ViewController: UISearchBarDelegate {

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
         searchedUser = resultArray!.filter({$0.name.first.lowercased().prefix(searchText.count) == searchText.lowercased()})
                 searching = true
                 detailTableView.reloadData()
         
     }
     
     func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
         self.searchBar.endEditing(true)
     }
    
     
         func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
             searching = false
            self.searchBar.text = ""
             detailTableView.reloadData()
             
     }



}
