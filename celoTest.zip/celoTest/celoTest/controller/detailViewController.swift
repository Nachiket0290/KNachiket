//
//  detailViewController.swift
//  celoTest
//
//  Created by Nachiket Kulkarni on 19/06/20.
//  Copyright © 2020 Nachiket. All rights reserved.
//

import UIKit
import SDWebImage

class detailViewController: UIViewController {
    
    
    var details : Result?

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        lblName.text = details?.name.first
        lblPhone.text = details?.phone
        lblCity.text = details?.location.city
        lblEmail.text = details?.email
        lblLocation.text = details?.location.street.name
        imgView.sd_setImage(with: URL(string: (details?.picture.large)!), completed: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
