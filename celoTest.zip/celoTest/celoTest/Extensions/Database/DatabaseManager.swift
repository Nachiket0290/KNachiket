//
//  DatabaseManager.swift
//  celoTest
//
//  Created by Nachiket Kulkarni on 19/06/20.
//  Copyright © 2020 Nachiket. All rights reserved.
//

import Foundation
var shareInstance = DatabaseManager()
class DatabaseManager: NSObject{
    
    var database:FMDatabase? = nil
    
    
    class func getInstance() -> DatabaseManager{
        if shareInstance.database == nil{
            shareInstance.database = FMDatabase(path: util.getPath("users.db"))
        }
        return shareInstance
    }
    
    // "INSERT All Data"
    func saveData(_ modelInfo:sqliteModel) -> Bool{
        shareInstance.database?.open()
        let isSave = shareInstance.database?.executeUpdate("INSERT INTO Alldata (allData) VALUES (?)", withArgumentsIn: [modelInfo.allData])
        shareInstance.database?.close()
        return isSave!
    }
    
    // "CLEAR All Data"
    
    func clearTable(_ name: String) -> Bool {
        shareInstance.database?.open()
        guard let isDeleted = shareInstance.database?.executeStatements("DELETE FROM \(name)") else {
            shareInstance.database?.close()
            return false }
        shareInstance.database?.close()
        if isDeleted {
            return true
        }
        return false
    }
    
    // "GET All Data"
    func getTableData() -> [Result] {
        var retArr = [Result]()
        let query = "select allData from AllData"
        shareInstance.database?.open()
        do {
            let results = try shareInstance.database?.executeQuery(query, values: nil)
            while (results?.next())! {
                let str = (results?.string(forColumn: "allData"))!
                let data = convertToDictionary(text: str)
                let result = try JSONDecoder().decode(Result.self, from: JSONSerialization.data(withJSONObject: data!))
                retArr.append(result)
                

            }
        }
        catch {
            print(error.localizedDescription)
        }
        
        
        shareInstance.database?.close()
        return retArr
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    

    
    
}
