//
//  stringFunctions.swift
//  celoTest
//
//  Created by Nachiket Kulkarni on 19/06/20.
//  Copyright © 2020 Nachiket. All rights reserved.
//

import Foundation

class stringFunctions {
    
    static func walkThroughArray(_ json: [Any]) -> Bool {
        let isDeleted = DatabaseManager.getInstance().clearTable("AllData")
        for item in json {
            let encoder = JSONEncoder()
            if let jsonData = try? encoder.encode(item as! Result) {
                if let jsonString = String(data: jsonData, encoding: .utf8) {
                    //jsonString
                  let modelInfo = sqliteModel(allData: jsonString)
                    if isDeleted {
                        let isSave = DatabaseManager.getInstance().saveData(modelInfo)
                        if !isSave {
                            return false
                        }
                    }
                    else
                    {
                        return false
                    }
                    
                }
            }
            
        }
        return true
    }
    
    
}
