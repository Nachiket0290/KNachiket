//
//  sqliteModel.swift
//  celoTest
//
//  Created by Nachiket Kulkarni on 19/06/20.
//  Copyright © 2020 Nachiket. All rights reserved.
//

import Foundation

struct sqliteModel: Codable {
    let allData: String
}
